package prácticas_finales;
/**
 * @author Bely_Vale
 */
import java.util.ArrayList;
public class RCompartido5 {
        private String rc;
        RCompartido5(){
            rc="";
        }
        
        public String getRC(){
            /*String aux="En espera...";
            if(IsEntra()){
                bloquea();
                aux=rc;
                desbloquea();
            }*/
            return rc;
        }
        
        public void setRc(String rc){
            /*for(Interrupcion i:interrupciones){
                if(i.isInter())
                    this.rc=rc;
            }*/
            this.rc=rc;
        }
     
}
