package prácticas_finales;
/**
 * @author Bely_Vale
 */
//Técnica de sincronización
import static java.lang.System.exit;
import javax.swing.JTextArea;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Hilo5 extends Thread {
        private  JTextArea area;
        private RCompartido5 rC;
        private boolean terminar;
        private final static int inic=995;
        private final static int fin=1000;
        private Lock mutex;
        Hilo5(JTextArea area, RCompartido5 rC){
                this.area = area;
                this.rC = rC;
                this.terminar=true;
                mutex=new ReentrantLock();//polimorfismo
        }
       
        public void run(){
                while(terminar){
                        try{
                            String aux="En espera...";
                            if(mutex.tryLock()){
                                mutex.lock();//hace un wait() para que otro proceso no entre
                                rC.setRc(this.getName());
                                area.append(  rC.getRC() + " come \n");
                                mutex.unlock();//notifica que ya salió de su sección crítica
                                
                           }else{
                                area.append(  aux + "\n");
                            }
                             Thread.sleep((int)(inic+(Math.random()*fin)));
                        }catch(Exception e){e.printStackTrace();}
                }
        }
        
        public void matarHilo(){            
          terminar=false;  
       }
}
