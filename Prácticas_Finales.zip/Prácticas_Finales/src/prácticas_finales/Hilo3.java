package prácticas_finales;
/**
 * @author Bely_Vale
 */
/*En este metodo se utiliza una variable compartida llamada cerradura*/
import javax.swing.JTextArea;
public class Hilo3 extends Thread {
        private  JTextArea area;
        private RCompartido3 rC;
        private VCerradura vcerr;
        private static int inic=995;
        private final static int fin=1000;
        public String nombre="";
        public boolean bandera=true;
        Hilo3(JTextArea area, RCompartido3 rC, VCerradura vcerr){
                this.area = area;
                this.rC = rC;
                this.vcerr=vcerr;
        }
       
        public void run(){
                int iter=0;
                while(true&&bandera){
                        try{
                            String aux="En espera...";
                            /*se pregunta por el valor de la variable cerradura, si es cero(false), */
                            if(!vcerr.isVcerr()){
                                vcerr.Cierra();//entonces el proceso cambia el valor de la variable a uno(true)
                                //que bloquea los demas procesos tratando de evitar las condiciones de competencia
                                //entra a su sección crítica
                                rC.setRc(this.getName());
                                area.append(  rC.getRc() + " Come \n");
                                //Cmbia el valor de la cerradura a false
                                vcerr.Abre();
                            }else{
                                /*considera el caso en el que el proceso no pueda entrar a utilizar el recurso compartido*/
                                area.append(  aux + "\n");
                            }
                            
                            /*if(nombre=="Perrito 3"){
                                CondicionesCompetencias.t1.interrupt();
                                CondicionesCompetencias.t1.bandera=false;
                                CondicionesCompetencias.t2.bandera=false;
                                CondicionesCompetencias.t3.bandera=false;
                                CondicionesCompetencias.t4.bandera=false;
                            }*/             
                             sleep(1000);
                             //int numAl= (int)(inic*(Math.random()*fin)) ;
                             //Thread.sleep((int)(inic+(Math.random()*fin)));
                        }catch(Exception e){System.out.println("");}
                        iter++;
                }
        }
        
        public void nombre(String nombre2){
            nombre=nombre2;
        }
}
