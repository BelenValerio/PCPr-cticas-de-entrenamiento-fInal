package prácticas_finales;

import java.util.logging.Level;
import java.util.logging.Logger;
/**
 * @author Bely_Vale
 */
public class Mutex {
    private boolean pase;
    Mutex(boolean pase){
        this.pase=pase;
    }
    
    synchronized  void lock(){
        while(pase){
            try {
                wait();
            } catch (InterruptedException ex) {
                System.out.println("ERROR"+ex.toString());
            }
        }
        pase=true;
    }
    
    synchronized  void unlock(){
        pase=false;
        notify();
    }
    
    synchronized boolean obten_pase(){
        return pase;
    }
    
    synchronized void pon_pase(boolean pase){
        pase=pase;
    }
}
