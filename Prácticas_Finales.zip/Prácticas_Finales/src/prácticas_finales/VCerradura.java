package prácticas_finales;
/**
 * @author Bely_Vale
 */
public class VCerradura {
    public boolean vcerr;
    VCerradura(){
        vcerr=false;
    }

    public boolean isVcerr() {
        return vcerr;
    }

    public void setVcerr(boolean vcerr) {
        this.vcerr = vcerr;
    }
    
    public void Cierra(){
        vcerr=true;
    }
    
    public void Abre(){
        vcerr=false;
    }
}
