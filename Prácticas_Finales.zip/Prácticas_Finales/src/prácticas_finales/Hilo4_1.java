package prácticas_finales;

/**
 *
 * @author Bely_Vale
 */
import static java.lang.System.exit;
import javax.swing.JTextArea;
public class Hilo4_1 extends Thread {
        private  JTextArea area;
        private RCompartido4 rC;
        private boolean terminar;
        private final static int inic=995;
        private final static int fin=1000;
        private Turno turn;
       

    Hilo4_1(JTextArea area, RCompartido4 rC) {
            this.area = area;
            this.rC = rC;
            this.terminar=true;
            turn=new Turno();
    }
     
        public void run(){
                while(terminar){
                        try{
                            String aux="En espera...";
                            while(turn.getTurn()==1){
                                if(turn.getTurn()==1){
                                turn.entrarSC(1);//indicar que no está listo(turn lo pone en 0)
                                rC.setRc(this.getName());
                                area.append(  rC.getRC() + " come \n");
                                turn.salirSC(0);//le doy un 1 el permiso a otro proceso
                                }    
                               Thread.sleep((int)(inic+(Math.random()*fin))); 
                            }     
                        }catch(Exception e){e.printStackTrace();}      
                }
        }
        
        public void matarHilo(){            
          terminar=false;  
       }
}
