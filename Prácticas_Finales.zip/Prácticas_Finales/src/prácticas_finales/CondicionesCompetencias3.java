package prácticas_finales;

import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.application.Platform.exit;
/**
 * @author Bely_Vale
 */
public class CondicionesCompetencias3 extends javax.swing.JFrame {
        private VCerradura vcerr;
        public CondicionesCompetencias3() {
                setTitle("LA CENA DE LOS PERRITOS");
                initComponents();
                vcerr=new VCerradura();
                rC = new RCompartido3();
                t1 = new Hilo3(Area1,rC,vcerr);
                t1.setName("Perrito 1");
                t2 = new Hilo3(Area2, rC,vcerr);
                t2.setName("Perrito 2");
                t3 = new Hilo3(Area3, rC,vcerr);
                t3.setName("Perrito 3");
                t4 = new Hilo3(Area4, rC,vcerr);
                t4.setName("Perrito 4");
                this.getContentPane().setBackground(new Color(225,249,163));
                
        }
@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btCorrer = new javax.swing.JButton();
        btPausa = new javax.swing.JButton();
        btTerminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Area1 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        Area2 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        Area3 = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        Area4 = new javax.swing.JTextArea();
        lbHilo2 = new javax.swing.JLabel();
        lbHilo3 = new javax.swing.JLabel();
        lbHilo4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 204, 204));

        btCorrer.setBackground(new java.awt.Color(163, 225, 122));
        btCorrer.setText("Correr");
        btCorrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCorrerActionPerformed(evt);
            }
        });

        btPausa.setBackground(new java.awt.Color(163, 225, 122));
        btPausa.setText("Kill -9");
        btPausa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPausaActionPerformed(evt);
            }
        });

        btTerminar.setBackground(new java.awt.Color(163, 225, 122));
        btTerminar.setText("Salir ");
        btTerminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btTerminarActionPerformed(evt);
            }
        });

        Area1.setColumns(20);
        Area1.setRows(5);
        jScrollPane1.setViewportView(Area1);

        Area2.setColumns(20);
        Area2.setRows(5);
        jScrollPane2.setViewportView(Area2);

        Area3.setColumns(20);
        Area3.setRows(5);
        jScrollPane3.setViewportView(Area3);

        Area4.setColumns(20);
        Area4.setRows(5);
        jScrollPane4.setViewportView(Area4);

        lbHilo2.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        lbHilo2.setText("Plato 2");

        lbHilo3.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        lbHilo3.setText("Plato 3");

        lbHilo4.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        lbHilo4.setText("Plato 4");

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel1.setText("Plato 1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(139, 139, 139)
                        .addComponent(lbHilo2, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(btPausa)
                                            .addComponent(btCorrer))
                                        .addGap(0, 18, Short.MAX_VALUE))
                                    .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(18, 18, 18))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(btTerminar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbHilo3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(123, 123, 123)
                        .addComponent(lbHilo4)
                        .addGap(135, 135, 135))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(lbHilo4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lbHilo2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lbHilo3, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
                            .addComponent(jScrollPane2)
                            .addComponent(jScrollPane3)
                            .addComponent(jScrollPane4)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(btCorrer)
                        .addGap(18, 18, 18)
                        .addComponent(btPausa)
                        .addGap(14, 14, 14)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btTerminar)))
                .addContainerGap(57, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

        private void btCorrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCorrerActionPerformed
                t1.start();
                t2.start();
                t3.start();
                t4.start();
        }//GEN-LAST:event_btCorrerActionPerformed

        private void btPausaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPausaActionPerformed
                String nombre2="Perrito 3";
                t1.nombre(nombre2);
                t1.bandera=false;
                t2.bandera=false;
                t3.bandera=false;
                t4.bandera=false;
                int numAl= (int) (Math.random()*3);
                switch(numAl){
                    case 1:
                        jTextField1.setText("El hilo "+numAl+ " ha muerto");
                        
                        break;
                    case 2:
                        jTextField1.setText("El hilo "+numAl+ " ha muerto");
                        
                        break;
                    case 3:
                        jTextField1.setText("El hilo "+numAl+ " ha muerto");
                        
                        break;
                    case 4:
                        jTextField1.setText("El hilo "+numAl+ " ha muerto");
                        
                        break;
                }     
        }//GEN-LAST:event_btPausaActionPerformed

        private void btTerminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btTerminarActionPerformed
                dispose();

        }//GEN-LAST:event_btTerminarActionPerformed

        public static void main(String args[]) {

                java.awt.EventQueue.invokeLater(new Runnable() {
                        public void run() {
                                new CondicionesCompetencias3().setVisible(true);
                        }
                });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea Area1;
    private javax.swing.JTextArea Area2;
    private javax.swing.JTextArea Area3;
    private javax.swing.JTextArea Area4;
    private javax.swing.JButton btCorrer;
    private javax.swing.JButton btPausa;
    private javax.swing.JButton btTerminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lbHilo2;
    private javax.swing.JLabel lbHilo3;
    private javax.swing.JLabel lbHilo4;
    // End of variables declaration//GEN-END:variables
    public static Hilo3 t1,t2, t3, t4;
        private RCompartido3 rC;
}
