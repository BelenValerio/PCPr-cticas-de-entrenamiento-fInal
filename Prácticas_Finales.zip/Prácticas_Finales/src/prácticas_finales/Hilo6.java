package prácticas_finales;
/**
 * @author Bely_Vale
 */
//Técnica de sincronización
import static java.lang.System.exit;
import javax.swing.JTextArea;

public class Hilo6 extends Thread {
        private  JTextArea area;
        private RCompartido6 rC;
        private boolean terminar;
        private final static int inic=995;
        private final static int fin=1000;
        private Mutex mutex;
        Hilo6(JTextArea area, RCompartido6 rC,Mutex mutex){
                this.area = area;
                this.rC = rC;
                this.terminar=true;
                this.mutex=mutex;
                
        }
       
        public void run(){
                while(terminar){
                        try{
                            String aux="En espera...";
                                mutex.lock();//cambia la variable pase a true
                                rC.setRc(this.getName());
                                area.append(  rC.getRC() + " come \n");
                                mutex.unlock();//cambia la variable pase a false
                                
                           
                             Thread.sleep((int)(inic+(Math.random()*fin)));
                        }catch(Exception e){e.printStackTrace();}
                }
        }
        
        public void matarHilo(){            
          terminar=false;  
       }
}
