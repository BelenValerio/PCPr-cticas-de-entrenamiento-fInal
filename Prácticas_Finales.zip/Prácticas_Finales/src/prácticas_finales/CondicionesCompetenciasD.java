package prácticas_finales;

import java.awt.Color;
import static java.lang.System.exit;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Bely_Vale
 */
public class CondicionesCompetenciasD extends javax.swing.JFrame {
        public CondicionesCompetenciasD() {
                initComponents();         
                rC = new RCompartidoD();
                t1 = new HiloD(Area1,rC);
                t1.setName("Perrito 1");
                t2 = new HiloD(Area2, rC);
                t2.setName("Perrito 2");
                t3 = new HiloD(Area3, rC);
                t3.setName("Perrito 3");
                t4 = new HiloD(Area4, rC);
                t4.setName("Perrito 4");
                this.getContentPane().setBackground(new Color(20,26,200));
                
        }
@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btCorrer = new javax.swing.JButton();
        btKill = new javax.swing.JButton();
        btTerminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Area1 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        Area2 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        Area3 = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        Area4 = new javax.swing.JTextArea();
        lbHilo2 = new javax.swing.JLabel();
        lbHilo3 = new javax.swing.JLabel();
        lbHilo4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btCorrer.setBackground(new java.awt.Color(255, 153, 153));
        btCorrer.setText("Correr");
        btCorrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCorrerActionPerformed(evt);
            }
        });

        btKill.setBackground(new java.awt.Color(255, 153, 153));
        btKill.setText("Kill");
        btKill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btKillActionPerformed(evt);
            }
        });

        btTerminar.setBackground(new java.awt.Color(255, 153, 153));
        btTerminar.setText("Exit");
        btTerminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btTerminarActionPerformed(evt);
            }
        });

        Area1.setColumns(20);
        Area1.setRows(5);
        jScrollPane1.setViewportView(Area1);

        Area2.setColumns(20);
        Area2.setRows(5);
        jScrollPane2.setViewportView(Area2);

        Area3.setColumns(20);
        Area3.setRows(5);
        jScrollPane3.setViewportView(Area3);

        Area4.setColumns(20);
        Area4.setRows(5);
        jScrollPane4.setViewportView(Area4);

        lbHilo2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbHilo2.setForeground(new java.awt.Color(255, 255, 255));
        lbHilo2.setText("Plato 2");

        lbHilo3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbHilo3.setForeground(new java.awt.Color(255, 255, 255));
        lbHilo3.setText("Plato 3");

        lbHilo4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbHilo4.setForeground(new java.awt.Color(255, 255, 255));
        lbHilo4.setText("Plato 4");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Plato 1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(19, 19, 19)
                                        .addComponent(btCorrer))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(28, 28, 28)
                                        .addComponent(btKill)))
                                .addGap(0, 35, Short.MAX_VALUE)))
                        .addGap(18, 18, 18))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(btTerminar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(203, 203, 203)
                .addComponent(jLabel1)
                .addGap(173, 173, 173)
                .addComponent(lbHilo2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbHilo3)
                .addGap(158, 158, 158)
                .addComponent(lbHilo4)
                .addGap(99, 99, 99))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lbHilo4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lbHilo3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(lbHilo2)
                    .addComponent(jLabel1))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
                            .addComponent(jScrollPane2)
                            .addComponent(jScrollPane3)
                            .addComponent(jScrollPane4)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(btCorrer)
                        .addGap(18, 18, 18)
                        .addComponent(btKill)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btTerminar)))
                .addContainerGap(52, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

        private void btCorrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCorrerActionPerformed
                t1.start();
                t2.start();
                t3.start();
                t4.start();
        }//GEN-LAST:event_btCorrerActionPerformed

        private void btKillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btKillActionPerformed
                
                int numAl= (int) (Math.random()*3);
                if(numAl==1||numAl==2||numAl==3||numAl==4){
                    jTextField1.setText("El perrito "+numAl+ " ha muerto");
                    if(numAl==1){
                       t1.matarHilo(); 
                    }
                    if(numAl==2){
                       t2.matarHilo(); 
                    }
                    if(numAl==3){
                       t3.matarHilo(); 
                    }
                    if(numAl==4){
                       t4.matarHilo(); 
                    }                             
                }
             
        }//GEN-LAST:event_btKillActionPerformed

        private void btTerminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btTerminarActionPerformed

                exit(0);
        }//GEN-LAST:event_btTerminarActionPerformed

        public static void main(String args[]) {
                /* Set the Nimbus look and feel */
                //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
                /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
                 */
                try {
                        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                                if ("Nimbus".equals(info.getName())) {
                                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                                        break;
                                }
                        }
                } catch (ClassNotFoundException ex) {
                        java.util.logging.Logger.getLogger(CondicionesCompetenciasD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (InstantiationException ex) {
                        java.util.logging.Logger.getLogger(CondicionesCompetenciasD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (IllegalAccessException ex) {
                        java.util.logging.Logger.getLogger(CondicionesCompetenciasD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (javax.swing.UnsupportedLookAndFeelException ex) {
                        java.util.logging.Logger.getLogger(CondicionesCompetenciasD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }
                //</editor-fold>
                //</editor-fold>
                //</editor-fold>
                //</editor-fold>
                //</editor-fold>
                //</editor-fold>
                //</editor-fold>
                //</editor-fold>

                /* Create and display the form */
                java.awt.EventQueue.invokeLater(new Runnable() {
                        public void run() {
                                new CondicionesCompetenciasD().setVisible(true);
                        }
                });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea Area1;
    private javax.swing.JTextArea Area2;
    private javax.swing.JTextArea Area3;
    private javax.swing.JTextArea Area4;
    private javax.swing.JButton btCorrer;
    private javax.swing.JButton btKill;
    private javax.swing.JButton btTerminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lbHilo2;
    private javax.swing.JLabel lbHilo3;
    private javax.swing.JLabel lbHilo4;
    // End of variables declaration//GEN-END:variables
        private HiloD t1,t2, t3, t4;
        private RCompartidoD rC;
        private boolean terminar=true;
        private boolean terminar2=true;
}
