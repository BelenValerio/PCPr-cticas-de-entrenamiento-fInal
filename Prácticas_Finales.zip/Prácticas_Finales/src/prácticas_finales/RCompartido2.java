package prácticas_finales;
/**
 * @author Bely_Vale
 */
import java.util.ArrayList;
public class RCompartido2 {
        private String rc;
        private ArrayList<Interrupcion>interrupciones;
        RCompartido2(){
            rc="";
            interrupciones=new ArrayList<Interrupcion>();
            for(int i=0;i<10;i++){
                interrupciones.add(new Interrupcion());
            }
        }
        
        public String getRC(){
            /*String aux="En espera...";
            if(IsEntra()){
                bloquea();
                aux=rc;
                desbloquea();
            }*/
            return rc;
        }
        
        public void setRc(String rc){
            /*for(Interrupcion i:interrupciones){
                if(i.isInter())
                    this.rc=rc;
            }*/
            this.rc=rc;
        }
        public ArrayList<Interrupcion> getInterrupciones(){
            return interrupciones;
        }
        
        public void setInterrpciones(ArrayList<Interrupcion> interrupciones){
            this.interrupciones=interrupciones;
        }
        
        public void bloquea(){
            for(Interrupcion inter:interrupciones)
                inter.setInter(false);            
        }
        
        public void desbloquea(){
            for(Interrupcion inter:interrupciones)
                inter.setInter(true);
        }
        
        public boolean IsEntra(){
            boolean ban=false;
            for(Interrupcion inter:interrupciones)
                if(inter.isInter())
                    ban=true;               
                else return false;     
            return ban;
        }
}
