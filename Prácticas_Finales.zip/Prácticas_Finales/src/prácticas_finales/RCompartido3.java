package prácticas_finales;
/**
 * @author Bely_Vale
 */
import static java.lang.Thread.sleep;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
public class RCompartido3 {    
    private String rc;
    public VCerradura vcerr;
    RCompartido3(){
        rc="";
        vcerr=new VCerradura();   
    }  
    
    public String getRc(){
        return rc;
    }
    
    public void setRc(String rc){
        this.rc=rc;
    }
}
