package prácticas_finales;
/**
 * @author Bely_Vale
 */
public class Interrupcion {
    private boolean inter;
    Interrupcion(){
        inter=true;
    }

    public boolean isInter() {
        return inter;
    }

    public void setInter(boolean inter) {
        this.inter = inter;
    }  
}
