package prácticas_finales;
/**
 * @author Bely_Vale
 */
import static java.lang.System.exit;
import java.util.Arrays;
import javax.swing.JTextArea;
public class HiloD extends Thread {
        private  JTextArea area;
        private RCompartidoD rC;
        private boolean terminar;
        private final static int inic=995;
        private final static int fin=1000;
        private int k=2,i=0,j=0,N=4;
        //Boolean[] b = new Boolean[4]; 
        boolean b[] = {true,true,true,true};
        boolean c[] = {true,true,true,true};
       // Boolean[] c = new Boolean[4]; 
        HiloD(JTextArea area, RCompartidoD rC){
                this.area = area;
                this.rC = rC;
                this.terminar=true;
                
        }
        
        
       
        public void run(){
                while(terminar){
                        try{ 
                            if(b[2]==false){
                               Li1(2,2); 
                            }else{
                                rC.setRc(this.getName());
                                area.append(  rC.getRC() + " come \n");
                            } 
                             Thread.sleep((int)(inic+(Math.random()*fin)));
                        }catch(Exception e){e.printStackTrace();}
                }
        }
        
        
        public void matarHilo(){            
          terminar=false;  
       }
       /*Para el i-ésimo computador*/ 
       public void Li1(int k,int i){
           if(k!=i){
               c[i]=true;
               if(b[k]){
                   k=i;
                   Li1(k,i);//para pasar al else
               }
           }
           else{
               c[i]=false;
               for(j=1;j<=N;j++){
                   //Busca los otros c[] verdaderos despues de haber establecido su c[] en false
                   if(j!=i && c[j]!=true){//Demuestra que no puede haber bloqueos infinitos
                       Li1(j,i);//esto permitirá que al menos 1 este en su sección crítica
                   }
               }
             /*sección crítica*/  
            rC.setRc(this.getName());
            area.append(  rC.getRC() + " come \n");
            c[i]=true;
            b[i]=true;
           }
       }
}
