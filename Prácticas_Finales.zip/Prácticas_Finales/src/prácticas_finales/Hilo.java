package prácticas_finales;

import javax.swing.JTextArea;
public class Hilo extends Thread {
        private  JTextArea area;
        private RCompartido rC;
        public boolean pausa;
        Hilo(JTextArea area, RCompartido rC, int num){
                this.area = area;
                this.rC = rC;
                this.pausa=false;
                this.setName(" Perrito " + num );
        }
        public void run(){
                while(true){
                        try{
                             rC.setDatoCompartido(this.getName());
                             area.append(  rC.getDatoCompartido() + " come \n");
                             sleep(1000);
                             while(pausa){//Si le damos clic en el botón de Pausa esta ahora es "true"
                                sleep(2000);//Entonces el hilo espera
                                pausa=false;
                            }
                        }catch(Exception e){e.printStackTrace();}
                }
        }
        
    public void pausa(){
       this.pausa=true; 
    }
 
}
