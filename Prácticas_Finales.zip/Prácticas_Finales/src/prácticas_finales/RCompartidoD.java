package prácticas_finales;
/**
 * @author Bely_Vale
 */
import java.util.ArrayList;
public class RCompartidoD {
        private String rc;
        RCompartidoD(){
            rc="";
        }
        
        public String getRC(){
            return rc;
        }
        
        public void setRc(String rc){
            /*for(Interrupcion i:interrupciones){
                if(i.isInter())
                    this.rc=rc;
            }*/
            this.rc=rc;
        }
}
