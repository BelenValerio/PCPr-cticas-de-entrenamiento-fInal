package prácticas_finales;
/**
 * @author Bely_Vale
 */
import java.util.ArrayList;
public class RCompartido6 {
        private String rc;
        RCompartido6(){
            rc="";
        }
        
        public String getRC(){
            return rc;
        }
        
        public void setRc(String rc){
            this.rc=rc;
        }
     
}
