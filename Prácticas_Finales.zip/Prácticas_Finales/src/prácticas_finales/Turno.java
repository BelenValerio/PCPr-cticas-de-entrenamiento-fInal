package prácticas_finales;
/**
 * @author Bely_Vale
 */
public class Turno {
    public int turn;
    Turno(){
        turn=1;
    }

    public int getTurn() {
        return turn;
    }

    public void setTurn(int turn) {
        this.turn = turn;
    }
    
    public void entrarSC(int iId) {
            turn=1-iId;
    }
    public void salirSC(int iId) {
        turn = 1 - iId;
    }
    
}
