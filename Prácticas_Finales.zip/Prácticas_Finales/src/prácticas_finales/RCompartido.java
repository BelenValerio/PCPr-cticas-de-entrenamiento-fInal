package prácticas_finales;

public class RCompartido {
        private String  datoCompartido;
        RCompartido(){
                datoCompartido = "";
        }
        
        public String getDatoCompartido() {
                return datoCompartido;
        }

        public void setDatoCompartido(String datoCompartido) {
                this.datoCompartido = datoCompartido;
        }    
}
