package prácticas_finales;
/**
 * @author Bely_Vale
 */
import static java.lang.System.exit;
import javax.swing.JTextArea;
public class Hilo2 extends Thread {
        private  JTextArea area;
        private RCompartido2 rC;
        private boolean terminar;
        private final static int inic=995;
        private final static int fin=1000;
        Hilo2(JTextArea area, RCompartido2 rC){
                this.area = area;
                this.rC = rC;
                this.terminar=true;
        }
       
        public void run(){
                while(terminar){
                        try{
                            String aux="En espera...";
                            if(rC.IsEntra()){
                                rC.bloquea();//desactiva las interrupciones
                                rC.setRc(this.getName());
                                area.append(  rC.getRC() + " come \n");
                                rC.desbloquea();//las activa nuevamente 
                           }else{
                                area.append(  aux + "\n");
                            }
                             Thread.sleep((int)(inic+(Math.random()*fin)));
                        }catch(Exception e){e.printStackTrace();}
                }
        }
        
        public void matarHilo(){            
          terminar=false;  
       }
}
